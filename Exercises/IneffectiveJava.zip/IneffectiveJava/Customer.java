import java.io.Serializable;
import java.math.BigInteger;
import java.util.Arrays;

public class Customer implements Serializable {
	public String accountType = new String("Checking");
	public Name name = new Name("First", "Last");
	public BigInteger account= new BigInteger("1");
	public Address address = null;
	public static Address addresses[] = new Address[0];
	public static long addresscount = 0;

	public synchronized Address getAddress(int addressIdx) {
		return addresses[addressIdx];
	}

	public synchronized void setAddress(Address address, int addressIdx) {
		this.addresses[addressIdx] = address;
	}

	public synchronized BigInteger getAccount() {
		return account;
	}

	public synchronized void setAccount(BigInteger account) {
		this.account = account;
	}

	public synchronized Address[] getAddress() {
		return addresses;
	}

	public synchronized void setAddress(Address[] address) {
		this.addresses = address;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((account == null) ? 0 : account.hashCode());
		result = prime * result + Arrays.hashCode(addresses);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (account == null) {
			if (other.account != null)
				return false;
		} else if (!account.equals(other.account))
			return false;
		if (!Arrays.equals(addresses, other.addresses))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Customer [account=" + account + ", address=" + address.toString() + "]";
	}
	public synchronized Customer Customer(int account, String first, String last, String line1, String line2, String city, String state, String zip) throws Exception {
		Customer customer = new Customer();
		customer.setAccount(new BigInteger(account+""));
		customer.name = new Name();
		name.first = first;
		name.last = last;
		Address address = (Address)Class.forName("Address").newInstance();
		Address[] newAddresses = new Address[customer.addresses.length+1];
		newAddresses[customer.addresses.length] = address;
		for (int i = 0; i < customer.addresses.length; i++) {
			addresscount = i;
			newAddresses[i] = customer.addresses[i];
		}
		customer.address.line1 = line1;
		customer.address.line2 = line2;
		Address.class.getField("city").set(address,city);
		Address.class.getField("state").set(address,state);
		Address.class.getField("zip").set(address,zip);
		return customer;
	}
	public synchronized void finalize() {
		for (Address address : addresses) {
			address = null;
		}
		addresscount = 0;
	}
}
