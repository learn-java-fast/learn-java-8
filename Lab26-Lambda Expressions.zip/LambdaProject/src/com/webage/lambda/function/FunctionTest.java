package com.webage.lambda.function;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.ToLongBiFunction;

import com.webage.lambda.person.Person;
import com.webage.lambda.person.PersonDatabase;
import com.webage.lambda.person.PersonOperations;

public class FunctionTest {

	public static void main(String[] args) {
		List<Person> people = PersonDatabase.createPersonList();

		
		
		
	}
	
	private static void useConsumer(List<Person> people, Predicate<Person> predicate, 
			Consumer<Person> outputPerson) {
		
		System.out.println("------- CA People - Stream -------");
		
		System.out.println("------- CA People - Method -------");
		
	}

	private static void useFunction(List<Person> people, Consumer<Person> outputPerson,
			Function<Person, String> fullAddress) {
		System.out.println("------- Function Demo -------");

	}

	private static void useSupplier(Consumer<Person> outputPerson) {
		System.out.println("------- Supplier Demo -------");

	}

	private static void useBiPredicate(List<Person> people, Consumer<Person> outputPerson,
			Function<Person, String> fullAddress) {
		System.out.println("------- BiPredicate Demo - NY People -------");

	}

	private static void useBiFunction(List<Person> people) {
		System.out.println("------- ToLongBiFunction Demo -------");

	}	

}
