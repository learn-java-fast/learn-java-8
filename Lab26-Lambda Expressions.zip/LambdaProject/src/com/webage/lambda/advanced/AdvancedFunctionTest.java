package com.webage.lambda.advanced;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.webage.lambda.employee.Employee;
import com.webage.lambda.employee.EmployeeDatabase;

public class AdvancedFunctionTest {
	private static List<Employee> employees = 
			EmployeeDatabase.createEmployeeList();
	private static BiConsumer<String, String> printStateMap = 
			(k, v) -> System.out.println("Key: " + k + " Value: " + v);

	public static void main(String[] args) {
		
	}

	private static Map<String, String> initializeStateMap() {
		Map<String, String> stateMap = new HashMap<>();
		
		stateMap.put("AZ", "Phoenix");
		stateMap.put("FL", "Tallahassee");
		stateMap.put("MI", "Lansing");
		stateMap.put("MD", "Annapolis");
		stateMap.put("CO", "Denver");
		return stateMap;
	}

	private static void useRemoveIf(List<Employee> employees) {
		System.out.println("--- RemoveIf MO Employees ---");
		
		
	}

	private static void useComputeIfAbsent(Map<String, String> stateMap) {
		System.out.println("--- ComputeIfAbsent Demo ---");
		

	}

	private static void useMerge(Map<String, String> stateMap) {
		System.out.println("--- Merge Demo ---");
		

	}

	private static void useReadAllLines() {
		System.out.println("--- readAllLines Demo ---");
		
		
	}

	private static void useFilesList() {
		System.out.println("--- Files.list Demo ---");
		
		
	}

	private static void useFilesWalk() {
		System.out.println("--- Files.walk Demo ---");
		
		
	}

	private static void useFlatMap() {
		System.out.println("--- flatMap Demo ---");
		
		
	}

}
