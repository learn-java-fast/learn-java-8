package com.webage.lambda.intro;

import java.util.List;
import java.util.function.Predicate;

import com.webage.lambda.person.Gender;
import com.webage.lambda.person.Person;
import com.webage.lambda.person.PersonDatabase;

public class PersonSearchTest {

	public static void main(String[] args) {
		List<Person> people = PersonDatabase.createPersonList();
		
		PersonSearch search = new PersonSearch();
		
		System.out.println("------- Calling Retirees -------");
		Predicate<Person> retirees = p -> p.getAge() >= 65;
        search.callMatchingPeople(people, retirees);
		
		System.out.println("------- Mailing New York -------");
		Predicate<Person> newYorkResidents = p -> p.getCity().equalsIgnoreCase("New York");
		search.mailMatchingPeople(people, retirees);
		
		System.out.println("------- Emailing Draftees -------");
		Predicate<Person> draftees = p -> p.getAge() >= 18
                && p.getAge() <= 25
                && p.getGender() == Gender.MALE;
		search.emailMatchingPeople(people, draftees);
	}

}
