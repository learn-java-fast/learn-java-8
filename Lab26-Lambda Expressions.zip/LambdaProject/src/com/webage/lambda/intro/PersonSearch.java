package com.webage.lambda.intro;

import java.util.List;
import java.util.function.Predicate;

import com.webage.lambda.person.Person;
import com.webage.lambda.person.PersonContact;

public class PersonSearch {
	PersonContact contact = new PersonContact();

	public void callMatchingPeople(List<Person> people, Predicate<Person> aTest) {
		for (Person p : people) {
			if (aTest.test(p)) {
				contact.callPerson(p);
			}
		}
	}

	public void mailMatchingPeople(List<Person> people, Predicate<Person> aTest) {
		for (Person p : people) {
			if (aTest.test(p)) {
				contact.mailPerson(p);
			}
		}
	}

	public void emailMatchingPeople(List<Person> people, Predicate<Person> aTest) {
		for (Person p : people) {
			if (aTest.test(p)) {
				contact.emailPerson(p);
			}
		}
	}

}
