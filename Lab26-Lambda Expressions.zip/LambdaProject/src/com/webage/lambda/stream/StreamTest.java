package com.webage.lambda.stream;

import java.util.List;

import com.webage.lambda.person.Person;
import com.webage.lambda.person.PersonDatabase;

public class StreamTest {

	public static void main(String[] args) {
		List<Person> people = PersonDatabase.createPersonList();

		
		
		
	}

}
