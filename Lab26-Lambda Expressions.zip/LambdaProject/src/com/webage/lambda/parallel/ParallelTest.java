package com.webage.lambda.parallel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.webage.lambda.employee.Employee;
import com.webage.lambda.employee.EmployeeDatabase;
import com.webage.lambda.employee.Role;

public class ParallelTest {

	public static void main(String[] args) {
		List<Employee> employees = EmployeeDatabase.createEmployeeList();
		
		convertOldStyle(employees);
	}

	private static void convertOldStyle(List<Employee> employees) {
		System.out.println("--- Convert from old style processing ---");
		
		double sum = 0;
		
		for (Employee e : employees) {
			if(e.getState().equals("CT") &&
				e.getRole().equals(Role.EXECUTIVE)) {
				System.out.println(e);
				sum += e.getSalary();
			}
		}

		System.out.printf("Total CT Executive Pay: $%,8.2f %n", sum);
	}

	private static void avoidStateful(List<Employee> employees) {
		System.out.println("--- Convert bad implementation ---");
		
		List<Employee> newList1 = new ArrayList<>();
		List<Employee> newList2 = new ArrayList<>();
		
		System.out.println("--- List 1 ---");

		newList1.forEach(e -> System.out.println(e));

		
		System.out.println("--- List 2 ---");

		newList2.forEach(e -> System.out.println(e));
	}

	private static void nonDeterministic(List<Employee> employees) {
		System.out.println("--- Non-Deterministic operation ---");
		

	}

	private static void demoReduction() {
		System.out.println("--- Reduction Demo ---");
		

	}

}
