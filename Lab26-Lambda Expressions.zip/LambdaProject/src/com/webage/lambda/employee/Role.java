package com.webage.lambda.employee;

public enum Role {
	STAFF, MANAGER, EXECUTIVE;
}
