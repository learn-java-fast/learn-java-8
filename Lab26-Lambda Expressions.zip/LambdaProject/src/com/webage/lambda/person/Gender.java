package com.webage.lambda.person;

public enum Gender {
	MALE, FEMALE;
}
