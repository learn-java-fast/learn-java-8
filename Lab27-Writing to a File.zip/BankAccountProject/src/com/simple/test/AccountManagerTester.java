package com.simple.test;

import java.io.IOException;

import com.simple.account.AccountManager;
import com.simple.account.BankAccount;
import com.simple.account.BusinessAccount;
import com.simple.account.SavingsAccount;

public class AccountManagerTester {

	public AccountManagerTester() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		AccountManager manager = new AccountManager();
		BankAccount account = new BankAccount(1, "Jeff Lebowski", 90f);
		SavingsAccount sAccount = new SavingsAccount(2, "Maude Lebowski", 10000f);
		BusinessAccount busAccount = new BusinessAccount(1000f, 3, "SimpleCorp", "123 Fake Street");

		manager.addAccount(account);
		manager.addAccount(sAccount);
		manager.addAccount(busAccount);
		
		manager.deposit(2, 100f);
		try {
			manager.persist();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		AccountManager readTest = new AccountManager();
		try {
			readTest.load();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(readTest);
	}

}
