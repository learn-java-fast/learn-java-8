package com.simple.account;

import java.io.Serializable;

public class BusinessAccount implements Account , Serializable{

	private float balance;

	public BusinessAccount(float balance, int accountID, String companyName, String companyAddress) {
		super();
		this.balance = balance;
		this.accountID = accountID;
		this.companyName = companyName;
		this.companyAddress = companyAddress;
	}

	private int accountID;
	private String companyName;
	private String companyAddress;

	public BusinessAccount() {
		// TODO Auto-generated constructor stub
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public int getAccountID() {
		return accountID;
	}

	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String toString() {
		return "A BusinessAccount belonging to  " + this.getCompanyName() + " with balance " + this.getBalance();
	}

	public void deposit(float amount) {
		this.setBalance(this.getBalance() + amount);
	}

	public void withdraw(float amount) throws InsufficientFundsException {
		if (amount > this.getBalance()) {
			throw new InsufficientFundsException("Amount " + amount + " exceeds 	balance " + this.getBalance());
		}
		this.setBalance(this.getBalance() - amount);
	}

}
