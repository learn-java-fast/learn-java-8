package com.simple.account;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.HashMap;

public class AccountManager {
	
	private HashMap<Integer, Account> accounts =
			new HashMap<>();
		
	public void deposit(int id, float amount) {
		Account account = this.accounts.get(id);
		account.deposit(amount);
	}

	public void withdraw (int id, float amount) throws InsufficientFundsException {
		Account account = this.accounts.get(id);
		account.withdraw(amount);
	}
	
	public void addAccount(Account account) {
		int key = account.getAccountID();
		this.accounts.put(key, account);
	}
	
	public Account getAccount(int id) {
		return (Account) this.accounts.get(id);
	}
	
	public String toString() {
		return this.accounts.toString();
	}
	
	public void persist() throws IOException {
		File f = new File("C:/Workspace/users.dat");
		OutputStream os = new FileOutputStream(f);
		try (ObjectOutputStream output = new ObjectOutputStream(os))
		{
			output.writeObject(this.accounts);
		} 
	}
	
	public  void load() throws IOException, ClassNotFoundException {
		File f = new File("C:/Workspace/users.dat");
		InputStream is = new FileInputStream(f);
		try (ObjectInputStream input = new ObjectInputStream(is)) {
			this.accounts=(HashMap<Integer, Account>)
				input.readObject();
		} 
	}
}
