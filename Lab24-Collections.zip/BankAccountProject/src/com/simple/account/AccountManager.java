package com.simple.account;

import java.util.HashMap;

public class AccountManager {
	
	private HashMap<Integer, Account> accounts =
			new HashMap<>();
		
	public void deposit(int id, float amount) {
		Account account = this.accounts.get(id);
		account.deposit(amount);
	}

	public void withdraw (int id, float amount) throws InsufficientFundsException {
		Account account = this.accounts.get(id);
		account.withdraw(amount);
	}
	
	public void addAccount(Account account) {
		int key = account.getAccountID();
		this.accounts.put(key, account);
	}
	
	public Account getAccount(int id) {
		return (Account) this.accounts.get(id);
	}
	
	public String toString() {
		return this.accounts.toString();
	}

}
