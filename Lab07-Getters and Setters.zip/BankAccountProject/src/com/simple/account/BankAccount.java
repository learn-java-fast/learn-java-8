package com.simple.account;

public class BankAccount {
	private int accountID;
	private String ownerName;
	private float balance;
	
	public void deposit(float amount) {
		balance = balance + amount;
	}
	
	public void setAccountID(int newID) {
		this.accountID = newID;
	}
	
	public int getAccountID() {
		return this.accountID;
	}
	
	public void setOwnerName(String newName) {
		this.ownerName = newName;
	}
		
	public String getOwnerName() {
		return this.ownerName;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		if(balance > 0f) {
	 		this.balance = balance;
		} else {
			System.out.println("Error.  Balance cannot be negative.");
		}
	}
}
