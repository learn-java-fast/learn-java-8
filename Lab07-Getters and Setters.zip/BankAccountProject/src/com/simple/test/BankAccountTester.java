package com.simple.test;

import com.simple.account.BankAccount;

public class BankAccountTester {

	public static void main(String[] args) {
		BankAccount account = new BankAccount();
		account.setAccountID(1);
		account.setOwnerName("Jeff Lebowski");
		account.setBalance(100f);
		account.deposit(50f);
		System.out.println("A Bank Account");
		System.out.println("ID: " + account.getAccountID());
		System.out.println("Balance: " + account.getBalance());
		System.out.println("Owner: " + account.getOwnerName());
	}

}
