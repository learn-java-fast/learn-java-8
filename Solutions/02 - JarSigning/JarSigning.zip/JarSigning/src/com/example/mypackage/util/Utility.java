package com.example.mypackage.util;

public class Utility {
	public void run() {
		System.out.println("Hello World");
	}
}
