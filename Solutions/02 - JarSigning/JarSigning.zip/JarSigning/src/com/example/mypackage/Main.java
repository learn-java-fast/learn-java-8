package com.example.mypackage;

import com.example.mypackage.util.Utility;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main main = new Main();
		main.run();
	}
	public void run() {
		new Utility().run();
	}
}
