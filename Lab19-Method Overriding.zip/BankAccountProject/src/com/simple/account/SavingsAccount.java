package com.simple.account;

public class SavingsAccount extends BankAccount {

	private float minimumBalance = 1000f;
	
	public SavingsAccount(int accountID, String ownerName, float balance) {
		super(accountID, ownerName, balance);
		// TODO Auto-generated constructor stub
	}
	
	public void payInterest() {
		float newBalance = this.getBalance() * (1 + 	(this.getInterestRate() / 100));
		if (this.getBalance() >= this.minimumBalance) {
		   this.setBalance(newBalance);
		}
	}
	
	public void print() {
		System.out.println("\nSavings Summary:");
		super.print();
		System.out.println("  Interest rate:" + this.getInterestRate());
		System.out.println("Minimum Balance:" + minimumBalance);
		}

	@Override
	public String toString() {
		return super.toString() + 
				" with interest rate " + this.getInterestRate() +
				" and minimum balance " + this.minimumBalance;	
	}

}
